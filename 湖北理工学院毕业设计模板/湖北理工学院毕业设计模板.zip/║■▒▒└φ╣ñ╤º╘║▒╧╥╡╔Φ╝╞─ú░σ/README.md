 # I
 本文是本人在完成课程论文时需要搜索对应latex模板  
 惊觉学校并未有学长分享  
 参照搜索到的模板 https://github.com/BHOSC/BUAAthesis  
 于是，本着不想让学弟学妹们经历同样的窘境，以拾人牙慧的稚笨模仿  
 有了此文  
 若有不当之处，恳请指正  
 Yuan Aiping-（Apy6631@outlook.com）  
 
 # II
 请将以下文件与此LaTeX文件放在同一目录中：  

    hbpu.cls-                       -LaTeX宏模板文件 
    bst/gbt7714-2005-numerical.bst- -国标参考文献BibTeX样式文件2005 
    bst/gbt7714-numerical.bst-      -国标参考文献BibTeX样式文件2015 
    pic/logoHBPU.png-               -论文封皮湖北理工学院字样 
    tex/*.tex-                      -本模板样例中的独立章节
